Searchable text reference for the Paperlords IGCSE archive
Built: 2026-10-04

Entries: 217 text files (216 active Paperlords records plus one recovered alternative).
Total extracted pages: 5347; total extracted text: 16,486,908 characters.

Each text file is a page-by-page extraction, with page markers and metadata. It contains the readable text from its PDF, including questions, mark schemes, examiner report advice, and accepted points where those appear.
Important: diagrams, charts, layout, handwriting, and some table geometry may not be represented fully in text. Consult the corresponding PDF in the complete PDF archive for visual details.
One exception: Paperlords’ Economics MayJune 2022 P2R QP PDF has zero readable pages. The original is retained in the PDF archive, and a verified 20-page alternate copy/text is included here under RECOVERED_ALTERNATIVES.

Use search_paperlords.py in the archive folder to search this index by phrase or keyword.
